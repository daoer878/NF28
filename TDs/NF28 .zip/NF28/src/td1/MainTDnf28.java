package td1;

import td2.ListView;

public class MainTDnf28 {
	public static void main(String[] args) {
		//td1();
		td2();
	}
	public static void td1() {
		ConsoleView consoleView = new ConsoleView("Console");
		ImageView imageView1= new ImageView("Image1");
		ImageView imageView2= new ImageView("Image2");
//		ImageView imageView3= new ImageView("Image3");
//		ImageView imageView4= new ImageView("Image4");
//		ImageView imageView5= new ImageView("Image5");
	}
	
	public static void td2() {
		ListView dict_view = new ListView("Mots");
	}
}
