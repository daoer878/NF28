package td2;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JList;
import javax.swing.JPanel;

public class DefinitionPane extends JPanel implements PropertyChangeListener{
	JList list_mot;

	@Override
	public void propertyChange(PropertyChangeEvent arg0) {
		// TODO Auto-generated method stub
	}
	
	
}
