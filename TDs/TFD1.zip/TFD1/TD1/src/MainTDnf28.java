
public class MainTDnf28 {
	public static void main(String[] args) {
		td1();
	}
	public static void td1() {
		ConsoleView consoleView = new ConsoleView();
		ImageView imageView= new ImageView();
	}
}
